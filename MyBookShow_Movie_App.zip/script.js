const seats = document.querySelectorAll(".seat");
const movie = document.getElementById("movie");

seats.forEach(seat => {
  seat.addEventListener("click", function () {
    this.classList.toggle("selected");
  });
});

movie.addEventListener("change", function () {
  const title = this.options[this.selectedIndex].text.split(" - ")[0];
  document.getElementById("movieTitle").textContent = title;
});

function bookTicket() {
  const time = document.getElementById("time");
  const selectedSeats = document.querySelectorAll(".seat.selected");

  if (selectedSeats.length === 0) {
    alert("Please select at least one seat.");
    return;
  }

  const movieName = movie.options[movie.selectedIndex].text;
  const showTime = time.value;
  const seatNames = [];

  selectedSeats.forEach(seat => seatNames.push(seat.innerText));

  document.getElementById("bookingDetails").innerHTML =
    "Movie: " + movieName +
    "<br>Show: " + showTime +
    "<br>Seats: " + seatNames.join(", ");

  document.getElementById("message").style.display = "block";
}

function closeBooking() {
  window.close();
  document.querySelector(".container").style.display = "none";
}
